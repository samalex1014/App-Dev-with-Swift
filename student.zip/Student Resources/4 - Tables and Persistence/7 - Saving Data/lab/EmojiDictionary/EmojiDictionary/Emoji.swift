
import Foundation

struct Emoji {
    var symbol: String
    var name: String
    var detailDescription: String
    var usage: String
}
